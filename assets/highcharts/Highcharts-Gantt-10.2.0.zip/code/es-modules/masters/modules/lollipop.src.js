/**
 * @license Highcharts JS v10.2.0 (2022-07-05)
 * @module highcharts/modules/lollipop
 * @requires highcharts
 *
 * (c) 2009-2021 Sebastian Bochan, Rafal Sebestjanski
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Lollipop/LollipopSeries.js';
